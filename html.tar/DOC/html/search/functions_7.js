var searchData=
[
  ['newnode_0',['newNode',['../class_t_s_t.html#aab2c6ab774cd73db65ff2c64a7f3d30f',1,'TST']]]
];
