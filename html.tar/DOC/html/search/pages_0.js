var searchData=
[
  ['super_20sopa_3a_20búsqueda_20de_20palabras_20en_20una_20sopa_20de_20letras_20estrambótica_2e_20documentación_2e_0',['Super Sopa: Búsqueda de palabras en una sopa de letras estrambótica. Documentación.',['../index.html',1,'']]]
];
