var searchData=
[
  ['matrix_0',['Matrix',['../_sopa_8cc.html#a368df7db643c0db8274b2154b2fe7018',1,'Sopa.cc']]]
];
