var searchData=
[
  ['limit_0',['LIMIT',['../_sopa_8cc.html#a5977928b042d0a4b2ce93baa979e5f5c',1,'Sopa.cc']]]
];
