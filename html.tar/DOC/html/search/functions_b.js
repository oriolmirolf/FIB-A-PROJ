var searchData=
[
  ['write_0',['write',['../class_sopa.html#aa38ef126dd679970630de7c76f5d7327',1,'Sopa']]]
];
