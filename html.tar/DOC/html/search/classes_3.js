var searchData=
[
  ['sopa_0',['Sopa',['../class_sopa.html',1,'']]],
  ['sortedvector_1',['SortedVector',['../class_sorted_vector.html',1,'']]]
];
